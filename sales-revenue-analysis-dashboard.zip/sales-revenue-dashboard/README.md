# Sales & Revenue Analysis Dashboard

An interactive Python Streamlit dashboard for retail sales KPIs, monthly trends, product rankings, category analysis and regional comparisons. Prepared as a portfolio/internship project using synthetic sample data.

## Tech stack
Python, Streamlit, Pandas, Plotly, CSV.

## Run locally
1. Install Python 3.10+.
2. Open this folder in VS Code.
3. Run:
   ```bash
   python -m pip install -r requirements.txt
   python -m streamlit run app.py
   ```
4. Open the localhost URL displayed in the terminal (normally http://localhost:8501).

## Features
- Revenue, order count, gross profit and gross margin KPIs
- Interactive date, region, category and product filters
- Monthly revenue/profit line chart
- Category bar chart, top-products ranking and region pie chart
- Data preview and filtered CSV download
- Upload a custom CSV matching the sample data's columns

## Dataset schema
`Order_ID,Order_Date,Region,Category,Product,Quantity,Unit_Price,Unit_Cost`

Order_Date should be YYYY-MM-DD. Unit prices and costs are in INR. Each sample order has one line item. The sample CSV is **synthetic** and not real business data.

## Calculations
- Revenue = Quantity × Unit_Price
- Profit = Quantity × (Unit_Price − Unit_Cost)
- Profit Margin = Profit / Revenue × 100
- Total Orders = count of unique Order_ID values

## Deploy on Streamlit Community Cloud
1. Push the repository to GitHub.
2. Visit https://share.streamlit.io/ and create a new app.
3. Select your GitHub repository, branch `main`, and entrypoint `app.py`.
4. Deploy and copy the public app URL.

## Submission
Submit your GitHub repository URL and (once deployed) the Streamlit app URL. Include screenshots from your running app if the internship portal requests them.

## Limitations
Profit here is an illustrative gross-profit proxy and excludes taxes, returns, logistics and overhead. Data are synthetic and intended for learning.
