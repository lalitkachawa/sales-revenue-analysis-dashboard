import io
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title='Sales & Revenue Dashboard', page_icon='📊', layout='wide')
st.title('📊 Sales & Revenue Analysis Dashboard')
st.caption('Interactive business intelligence project | Sample retail transactions')

@st.cache_data
def sample_data():
    return pd.read_csv('data/sample_sales.csv', parse_dates=['Order_Date'])

uploaded = st.sidebar.file_uploader('Upload your sales CSV', type=['csv'])
try:
    df = pd.read_csv(uploaded) if uploaded is not None else sample_data()
    required = ['Order_ID','Order_Date','Region','Category','Product','Quantity','Unit_Price','Unit_Cost']
    missing = [x for x in required if x not in df.columns]
    if missing:
        st.error('Missing required columns: ' + ', '.join(missing))
        st.stop()
    df['Order_Date'] = pd.to_datetime(df['Order_Date'], errors='coerce')
    for col in ['Quantity','Unit_Price','Unit_Cost']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df = df.dropna(subset=['Order_Date','Quantity','Unit_Price','Unit_Cost']).copy()
    df['Revenue'] = df['Quantity'] * df['Unit_Price']
    df['Profit'] = df['Quantity'] * (df['Unit_Price'] - df['Unit_Cost'])
except Exception as exc:
    st.error(f'Could not read data: {exc}')
    st.stop()

if df.empty:
    st.warning('No valid transactions available.')
    st.stop()

st.sidebar.header('Filters')
start, end = st.sidebar.date_input('Order date range', value=(df.Order_Date.min().date(), df.Order_Date.max().date()), min_value=df.Order_Date.min().date(), max_value=df.Order_Date.max().date())
regions = st.sidebar.multiselect('Regions', sorted(df.Region.dropna().unique()), default=sorted(df.Region.dropna().unique()))
categories = st.sidebar.multiselect('Categories', sorted(df.Category.dropna().unique()), default=sorted(df.Category.dropna().unique()))
products = st.sidebar.multiselect('Products (optional)', sorted(df.Product.dropna().unique()))
mask = df.Order_Date.dt.date.between(start, end) & df.Region.isin(regions) & df.Category.isin(categories)
if products:
    mask &= df.Product.isin(products)
filtered = df.loc[mask].copy()
if filtered.empty:
    st.warning('No transactions match your filters. Try expanding your selection.')
    st.stop()

revenue = filtered.Revenue.sum()
profit = filtered.Profit.sum()
orders = filtered.Order_ID.nunique()
margin = 100 * profit / revenue if revenue else 0
cols = st.columns(4)
for col, label, value in zip(cols, ['Total Revenue','Total Orders','Total Profit','Profit Margin'], [f'₹{revenue:,.0f}',f'{orders:,}',f'₹{profit:,.0f}',f'{margin:.1f}%']):
    col.metric(label, value)

monthly = filtered.assign(Month=filtered.Order_Date.dt.to_period('M').dt.to_timestamp()).groupby('Month',as_index=False)[['Revenue','Profit']].sum()
left,right = st.columns(2)
with left:
    st.subheader('Monthly Revenue & Profit')
    fig = px.line(monthly, x='Month', y=['Revenue','Profit'], markers=True, labels={'value':'Amount (₹)','variable':'Metric'})
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader('Revenue by Category')
    category = filtered.groupby('Category',as_index=False).Revenue.sum().sort_values('Revenue',ascending=False)
    st.plotly_chart(px.bar(category,x='Category',y='Revenue',color='Category',labels={'Revenue':'Revenue (₹)'}),use_container_width=True)
left,right = st.columns(2)
with left:
    st.subheader('Top 10 Products by Revenue')
    top = filtered.groupby('Product',as_index=False).Revenue.sum().nlargest(10,'Revenue').sort_values('Revenue')
    st.plotly_chart(px.bar(top,x='Revenue',y='Product',orientation='h',labels={'Revenue':'Revenue (₹)'}),use_container_width=True)
with right:
    st.subheader('Revenue by Region')
    region = filtered.groupby('Region',as_index=False).Revenue.sum()
    st.plotly_chart(px.pie(region,names='Region',values='Revenue',hole=.48),use_container_width=True)

st.subheader('Business Insights')
best_category = category.iloc[0]['Category']
best_region = filtered.groupby('Region').Revenue.sum().idxmax()
best_product = filtered.groupby('Product').Revenue.sum().idxmax()
st.info(f'Top category: **{best_category}** · Top region: **{best_region}** · Highest-revenue product: **{best_product}** · Average order value: **₹{revenue/orders:,.2f}**')
st.subheader('Filtered Transactions')
st.dataframe(filtered.sort_values('Order_Date',ascending=False),use_container_width=True,hide_index=True)
st.download_button('⬇️ Download filtered CSV',data=filtered.to_csv(index=False).encode('utf-8'),file_name='filtered_sales.csv',mime='text/csv')
st.caption('Revenue = Quantity × Unit Price; Profit = Quantity × (Unit Price − Unit Cost). Profit excludes taxes, shipping and overhead.')
